package awt_applet;

import java.applet.Applet;
import java.awt.Button;
import java.awt.Graphics;
import java.awt.Label;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class DrawLine extends Applet implements ActionListener{
	TextField tf1,tf2,tf3,tf4;
	Label x1,y1,x2,y2;
	Button btn;
	
	public void init() {
		//���� ���۰� �� ��ǥ�� �Է¹޴´�
		x1 = new Label("x1 : ");
		y1 = new Label("y1 : ");
		x2 = new Label("x2 : ");
		y2 = new Label("y2 : ");
		tf1 = new TextField("0",3);
		tf2 = new TextField("0",3);
		tf3 = new TextField("0",3);
		tf4 = new TextField("0",3);
		btn = new Button("draw");
		
		add(x1);
		add(tf1);
		add(y1);
		add(tf2);
		add(x2);
		add(tf3);
		add(y2);
		add(tf4);
		add(btn);
		
		btn.addActionListener(this);
	}
	
	public void paint(Graphics g) {
		//int x1 = Integer.valueOf(tf1.getText()).intValue();
		int x1 = Integer.parseInt(tf1.getText());
		int y1 = Integer.parseInt(tf2.getText());
		int x2 = Integer.parseInt(tf3.getText());
		int y2 = Integer.parseInt(tf4.getText());
		
		g.drawLine(x1, y1, x2, y2);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		//��ư�� Ŭ���Ǹ� �Է��� ��ǥ�� �ش��ϴ� ���� �׸���
		if(e.getSource() == btn) {
			repaint();	
		}
	}
}

package awt_applet;

import java.applet.Applet;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class ImageFlip extends Applet implements ItemListener{
	Image image;
	Choice choice;
	int flip = 0;
	
	public void init() {
		setBackground(Color.BLUE);
		
		image = getImage(getCodeBase(),"italia.jpg");
		choice = new Choice();
		choice.addItem("����");
		choice.addItem("�¿��Ī");
		choice.addItem("���ϴ�Ī");
		choice.addItem("180�� ȸ��");
		choice.select(0);
		
		add(choice);
		
		choice.addItemListener(this);
	}
	
	public void paint(Graphics g) {
		//choice���� ������ flip�� ���� �̹����� �����´�
		switch(flip) {
		case 0:
			//���� �̹���
			g.drawImage(image,0,0,this);
			break;
		case 1:
			//�¿� ��Ī
			g.drawImage(image,image.getWidth(this),0,0,image.getHeight(this),0,0,image.getWidth(this),image.getHeight(this),this);
			break;
		case 2:
			//���ϴ�Ī
			g.drawImage(image,0,image.getHeight(this),image.getWidth(this),0,0,0,image.getWidth(this),image.getHeight(this),this);
			break;
		case 3:
			//180�� ������
			g.drawImage(image,0,0,image.getWidth(this),image.getHeight(this),image.getWidth(this),image.getHeight(this),0,0,this);
			break;
		}
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		flip = choice.getSelectedIndex();
		repaint();
	}

}

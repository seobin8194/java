package awt_applet;

import java.applet.Applet;
import java.awt.Choice;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class ImageScaling extends Applet implements ItemListener{
	Image image;
	Choice choice;
	int scale = 1;
	
	public void init() {
		setBackground(Color.BLUE);
		
		image = getImage(getCodeBase(),"italia.jpg");
		choice = new Choice();
		choice.addItem("50%");
		choice.addItem("100%");
		choice.addItem("30%");
		choice.select(1);
		
		add(choice);
		
		choice.addItemListener(this);
	}
	
	public void paint(Graphics g) {
		
		
		
		//choice���� ������ scale�� ���� �̹��� ũ�⸦ �����Ѵ�
		switch(scale) {
		case 0:
			//1/2����Ѵ�
			g.drawImage(image,0,0,image.getWidth(this)/2,image.getHeight(this)/2,0,0,image.getWidth(this),image.getHeight(this),this);
			break;
		case 1:
			//���� ũ��
			g.drawImage(image,0,0,this);
			break;
		case 2:
			//1/3����Ѵ�
			g.drawImage(image,0,0,image.getWidth(this)/3,image.getHeight(this)/3,0,0,image.getWidth(this),image.getHeight(this),this);
			break;
		}	
		
		//�̹��� ũ��
		g.drawString("���� : " + image.getWidth(this), 10, 10);
		g.drawString("���� : " + image.getHeight(this), 10, 30);	
	}

	@Override
	public void itemStateChanged(ItemEvent e) {
		scale = choice.getSelectedIndex();
		repaint();
	}
}

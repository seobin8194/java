package awt_component;

import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Toolkit;

//Frame : container, �ϳ��� ������ ȭ���� �����
public class FrameEx {

	public static void main(String[] args) {
		//Constructs a new, initially invisible Frame object with the specified title.
		Frame f = new Frame("�׽�Ʈ");
		
		//Resizes this component so that it has width width and height height.
		f.setSize(500, 500);
		
		Toolkit tk = Toolkit.getDefaultToolkit();
		//abstract Dimension getScreenSize() : Gets the size of the screen, return Dimension class
		//Dimension class : ������ ��Ÿ���� Ŭ����
		Dimension screenSize = tk.getScreenSize();
		System.out.println(screenSize);
		
		//Moves this component to a new location.
		f.setLocation(screenSize.width/2 - f.getWidth()/2, screenSize.height/2 - f.getHeight()/2);
		
		//Shows or hides this Window depending on the value of parameter
		f.setVisible(true);
	}

}

package awt_component;

import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;

public class PanelEx extends Frame{
	Label lab,lab2;
	TextField tf,tf2;
	Button btn;
	Panel p1,p2;
	
	public PanelEx() {
		super("panelTest");
		setSize(400,500);
		setLayout(new FlowLayout());
		
		p1 = new Panel();
		p1.setBackground(Color.PINK);
		lab = new Label("id");
		p1.add(lab);
		tf = new TextField(20);
		p1.add(tf);
		btn = new Button("ok");
		p1.add(btn);
		add(p1);
		
		p2 = new Panel();
		add(p2);
		p2.setBackground(Color.CYAN);
		lab2 = new Label("��й�ȣ");
		p2.add(lab2);
		tf2 = new TextField(30);
		p2.add(tf2);
	}

	public static void main(String[] args) {
		PanelEx f = new PanelEx();
		f.setVisible(true);
	}

}

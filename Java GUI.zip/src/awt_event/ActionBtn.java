package awt_event;

import java.awt.Button;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionBtn extends Frame implements ActionListener {
	Button redBtn,blueBtn,greenBtn;

	public ActionBtn() {
		super("ActionEventTest");
		setLayout(new FlowLayout());
		setBounds(200,200,300,400);
		
		redBtn = new Button("red");
		blueBtn = new Button("blue");
		greenBtn = new Button("green");
		
		add(redBtn);
		add(blueBtn);
		add(greenBtn);
		
		redBtn.addActionListener(this);
		blueBtn.addActionListener(this);
		greenBtn.addActionListener(this);
	}

	public static void main(String[] args) {
		new ActionBtn().setVisible(true);
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("��ư�� Ŭ���Ǿ��� ��");
		
		//getActionCommand() : Returns the eventSource string associated with this action
		String str = e.getActionCommand();//��ư�� ���ڿ��� ��ȯ�Ѵ�
		
		//Ŭ���� ��ư�� ���� ������ �����Ѵ�
		if(str.equals("red")) {
			setBackground(Color.red);
		}else if(str.equals("green")) {
			setBackground(Color.green);
		}else {
			setBackground(Color.blue);
		}	
	}
}

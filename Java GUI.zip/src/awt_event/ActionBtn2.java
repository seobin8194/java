package awt_event;

import java.awt.Button;
import java.awt.Color;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ActionBtn2 extends Frame implements ActionListener{
	Button btn[] = new Button[4];
	String str[] = {"green","blue","cyan","red"};
	Color color = new Color(240,240,240);
	
	 public ActionBtn2() {
		 super("actionEvent");
		 setBounds(200,200,300,300);
		 setLayout(new GridLayout(2, 2, 20, 20));
		 
		 for(int i = 0; i < btn.length; i++) {
			 btn[i] = new Button(str[i]);
			 add(btn[i]);
			 btn[i].addActionListener(this);
		 } 	 
	 }
	 
	@Override
	public void actionPerformed(ActionEvent e) {
		System.out.println("��ư�� Ŭ���Ǿ��� ��");
		
		//getActionCommand() : Returns the eventSource string associated with this action
		String str = e.getActionCommand();
		
		//Ŭ���� ��ư�� ���� Ŭ���� ��ư ������ ������ �ش� ������ �����Ѵ�
		//�ѹ� �� ������ ���� ������ ���� �´�
		if(str.equals("green")) {
			if(btn[0].getBackground() == Color.green) {
				btn[0].setBackground(color);
				setBackground(Color.WHITE);
			}else {
				btn[0].setBackground(Color.green);
			    setBackground(Color.green);
			}
		}else if(str.equals("blue")) {
			if(btn[1].getBackground() == Color.blue) {
				btn[1].setBackground(color);
				setBackground(Color.WHITE);
			}else {
			    btn[1].setBackground(Color.BLUE);
			    setBackground(Color.blue);
			}
		}else if(str.equals("cyan")){
			if(btn[2].getBackground() == Color.cyan) {
				btn[2].setBackground(color);
				setBackground(Color.WHITE);
			}else {
			    btn[2].setBackground(Color.cyan);
			    setBackground(Color.cyan);
			}    
		}else if(str.equals("red")) {
			if(btn[3].getBackground() == Color.red) {
				btn[3].setBackground(color);
				setBackground(Color.WHITE);
			}else {
			    btn[3].setBackground(Color.red);
			    setBackground(Color.red);
			}
		}	
	}	 
	 

	public static void main(String[] args) {
		new ActionBtn2().setVisible(true);
	}
}

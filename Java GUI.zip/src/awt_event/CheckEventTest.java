package awt_event;

import java.awt.Button;
import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Frame;
import java.awt.GridLayout;
import java.awt.Label;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CheckEventTest extends Frame{
	Checkbox ch1,ch2,ch3,ch4,ch5,ch6,ch7,ch8;
	CheckboxGroup checkboxGroup;
	Button btn;
	Label l1,l2,result;
	
	public CheckEventTest(String title) {
		super(title);
		setBounds(100,100,500,400);
		setLayout(new GridLayout(12,1));
		
		l1 = new Label("����� ��̻�Ȱ�� ��� �����ÿ�");
		l2 = new Label("����� ������?");
		result = new Label("����� ");
		ch1 = new Checkbox("���� ");
		ch2 = new Checkbox("������");
		ch3 = new Checkbox("����");
		ch4 = new Checkbox("��Ÿ");
		checkboxGroup = new CheckboxGroup();
		ch5 = new Checkbox("10",checkboxGroup,false);
		ch6 = new Checkbox("20",checkboxGroup,false);
		ch7 = new Checkbox("30",checkboxGroup,false);
		ch8 = new Checkbox("40",checkboxGroup,false);
		btn = new Button("���");
		
		add(l1);
		add(ch1);
		add(ch2);
		add(ch3);
		add(ch4);
		add(l2);
		add(ch5);
		add(ch6);
		add(ch7);
		add(ch8);
		add(btn);
		add(result);
		
		btn.addActionListener(new ActionListener() {
			String str = "";
			String str2="";
			@Override
			public void actionPerformed(ActionEvent e) {
				if(ch1.getState()) {str += ch1.getLabel();}
				if(ch2.getState()) {str += ch2.getLabel();}
				if(ch3.getState()) {str += ch3.getLabel();}
				if(ch4.getState()) {str += ch4.getLabel();}
				
				if(ch5.getState()) {str2 = ch5.getLabel();}
				if(ch6.getState()) {str2 = ch6.getLabel();}
				if(ch7.getState()) {str2 = ch7.getLabel();}
				if(ch8.getState()) {str2 = ch8.getLabel();}
				
				result.setText("��� : ����� ��̴� " + str +" ����� ������ " + str2);
			}
		});
	}

	public static void main(String[] args) {
		new CheckEventTest("checkEventEx").setVisible(true);
	}
}

package awt_event;

public class InnerClassEx2 {

	public static void main(String[] args) {
		Outer1 ot1 = new Outer1();
		Outer1.Inner oi = ot1.new Inner();
		oi.InnerFunc();
	}
}

class Outer1{
	int value = 100;
	
	class Inner{
		int value = 200;
		
		void InnerFunc() {
			int value = 300;
			System.out.println("InnerFunc�� value : " + value);
			System.out.println("InnerŬ������ value : " + this.value);
			System.out.println("Outer1Ŭ������ value : " + Outer1.this.value);
		}
	}
}

package awt_event;

import java.awt.Checkbox;
import java.awt.CheckboxGroup;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.Frame;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

public class ItemEventEx extends Frame{
	Checkbox chkb1,chkb2,chkb3;
	CheckboxGroup checkboxGroup;
	
	public ItemEventEx() {
		super("ItemEvent Test");
		setLayout(new FlowLayout());
		setBounds(100,100,300,300);
		setBackground(Color.GREEN);
		
		checkboxGroup = new CheckboxGroup();
		chkb1 = new Checkbox("����", checkboxGroup, true);
		chkb2 = new Checkbox("�Ķ�",checkboxGroup,false);
		chkb3 = new Checkbox("���",checkboxGroup,false);
		
		add(chkb1);
		add(chkb2);
		add(chkb3);
		
		chkb1.addItemListener(new EventHandler());
		chkb2.addItemListener(new EventHandler());
		chkb3.addItemListener(new EventHandler());
	}
	
	class EventHandler implements ItemListener{
		@Override
		public void itemStateChanged(ItemEvent e) {
			Checkbox chkb = (Checkbox) e.getSource();
			String label = chkb.getLabel();
			if(label.equals("����")) {
				setBackground(Color.red);
				chkb1.setBackground(Color.red);
				chkb2.setBackground(Color.red);
				chkb3.setBackground(Color.red);
			}else if(label.equals("�Ķ�")){
				setBackground(Color.blue);
				chkb1.setBackground(Color.BLUE);
				chkb2.setBackground(Color.BLUE);
				chkb3.setBackground(Color.BLUE);
			}else {
				setBackground(Color.YELLOW);
				chkb1.setBackground(Color.yellow);
				chkb2.setBackground(Color.yellow);
				chkb3.setBackground(Color.yellow);
			}
		}
	}

	public static void main(String[] args) {
		new ItemEventEx().setVisible(true);
	}
}

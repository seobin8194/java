package awt_event;

import java.awt.Color;
import java.awt.FileDialog;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MenuEx extends Frame{
	MenuBar bar;
	Menu file, tool,bgColor,fontColor;
	MenuItem open,save,exit,black,gray,white,red;
	Label label;
	
	public MenuEx() {
		super("Menu");
		setBounds(200,200,300,400);
		
		//MenuBar
		bar = new MenuBar();
		setMenuBar(bar);
		
		//Menu(String label)
		file = new Menu("����");
		bar.add(file);
		
		//MenuItem(String label)
		open = new MenuItem("����");
		file.add(open);
		save = new MenuItem("����");
		file.add(save);
		//MenuItem���� ���м� �߰�
		file.addSeparator();
		exit = new MenuItem("����");
		file.add(exit);
		
		//MenuItem�� �̺�Ʈ�ڵ鷯 ����
		EventHandler eventHandler = new EventHandler();
		open.addActionListener(eventHandler);
		save.addActionListener(eventHandler);
		exit.addActionListener(eventHandler);
		
		//Menu
		tool = new Menu("����");
		bar.add(tool);
		
		//subMenu
		bgColor = new Menu("����");
		tool.add(bgColor);
		
		//subMenu�� MeuItem
		black = new MenuItem("����");
		bgColor.add(black);
		gray = new MenuItem("ȸ��");
		bgColor.add(gray);
		
		//MenuItem�� �̺�Ʈ�ڵ鷯 ����
		black.addActionListener(eventHandler);
		gray.addActionListener(eventHandler);
		
		//subMenu
		fontColor = new Menu("���ڻ�");
		tool.add(fontColor);
		
		//subMenu�� MeuItem
		white = new MenuItem("���");
		fontColor.add(white);
		red = new MenuItem("����");
		fontColor.add(red);
		
		//MenuItem�� �̺�Ʈ�ڵ鷯 ����
		white.addActionListener(eventHandler);
		red.addActionListener(eventHandler);
		
		label = new Label("�޴��׽�Ʈ�ϱ�", Label.CENTER);
		add(label,"South");
	}
	
	class EventHandler implements ActionListener{
		Color bgColor = Color.white;
		Color fColor = Color.black;

		@Override
		public void actionPerformed(ActionEvent e) {
			Object object = e.getSource();
			//System.out.println(object);
			
			if(object == open) {
				//FileDialog
				//FileDialog(Frame parent,String title,int mode) 
				//Creates a file dialog window with the specified title for loading or saving a file
				FileDialog fd = new FileDialog(MenuEx.this,"open",FileDialog.LOAD);
				fd.setVisible(true);
			}else if(object == save) {
				FileDialog fd = new FileDialog(MenuEx.this,"save",FileDialog.SAVE);
				fd.setVisible(true);
			}else if(object == exit) {
				System.exit(0);
			}else if(object == black) {
				bgColor = Color.BLACK;
				fColor = Color.WHITE;
			}else if(object == gray) {
				bgColor = Color.gray;
			}else if(object == white) {
				fColor = Color.white;
			}else if(object == red) {
				fColor = Color.red;
			}
			
			setBackground(bgColor);
			label.setBackground(bgColor);
			label.setForeground(fColor);		
		}
	}

	public static void main(String[] args) {
		new MenuEx().setVisible(true);
	}
}

package awt_event;

import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;
import java.awt.MenuItem;
import java.awt.Point;
import java.awt.PopupMenu;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class PopUpEx extends Frame{
	PopupMenu popupMenu;
	MenuItem copy,cut,paste;
	Label label;
	
	public PopUpEx() {
		super("Popup Test");
		setBounds(100,100,500,500);
		
		//PopupMenu ����
		popupMenu = new PopupMenu();
		add(popupMenu);
		
		//PopupMenu�� MenuItem����
		copy = new MenuItem("copy");
		cut = new MenuItem("cut");
		paste = new MenuItem("paste");
		popupMenu.add(copy);
		popupMenu.add(cut);
		popupMenu.add(paste);
		
		label = new Label("",Label.CENTER);
		label.setBackground(Color.magenta);
		add(label,"South");
		
		//Frame�� Ŭ������ �� �˾��޴��� ���
		this.addMouseListener(new EventHandler());
	}
	
	class EventHandler implements MouseListener{

		@Override
		public void mouseClicked(MouseEvent e) {
			//getPoint() 
			//Returns the x,y position of the event relative to the source component
			Point point = e.getPoint();
			int x = point.x;
			int y = point.y;
			
			label.setText("x : " + x + "  y : " + y);
			
			//getButton() 
			//Returns which, if any, of the mouse buttons has changed state
			//BUTTON1:���ʹ�ư BUTTON2:�� BUTTON3:�����ʹ�ư
			if(e.getButton() == e.BUTTON3) {
				//���콺Ŭ���̺�Ʈ�� �Ͼ ��ġ�� �˾��޴��� �ٿ��
			    //show(Component origin,int x,int y) 
			    //Shows the popup menu at the x, y position relative to an origin component.
			    popupMenu.show(PopUpEx.this, x, y);
			}
		}

		@Override
		public void mousePressed(MouseEvent e) {
			setBackground(Color.BLACK);
		}

		@Override
		public void mouseReleased(MouseEvent e) {
			setBackground(Color.DARK_GRAY);
		}

		@Override
		public void mouseEntered(MouseEvent e) {
			setBackground(Color.CYAN);
		}

		@Override
		public void mouseExited(MouseEvent e) {
			setBackground(Color.BLUE);
		}	
	}

	public static void main(String[] args) {
		new PopUpEx().setVisible(true);
	}
}

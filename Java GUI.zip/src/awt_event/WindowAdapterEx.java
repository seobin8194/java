package awt_event;

import java.awt.Frame;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

public class WindowAdapterEx extends Frame{
	public WindowAdapterEx() {
		super("Window Adapter Test");
		setSize(300,300);
		
		EventHandler eventHandler = new EventHandler();
		addWindowListener(eventHandler);
	}
	
	class EventHandler extends WindowAdapter{
		public void windowClosing(WindowEvent e) {
			System.exit(0);
		}
	}

	public static void main(String[] args) {
		new WindowAdapterEx().setVisible(true);
	}
}

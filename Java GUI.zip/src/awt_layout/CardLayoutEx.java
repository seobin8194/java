package awt_layout;

import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Frame;
import java.awt.Label;
import java.awt.Panel;

public class CardLayoutEx extends Frame{
	CardLayout cardLayout;
	Panel pan1,pan2,pan3,pan4;
	Label l1;
	
	public CardLayoutEx() {
		super("cardLayout");
		setBounds(300,300, 300, 300);
		cardLayout = new CardLayout();
		setLayout(cardLayout);
		
		pan1 = new Panel();
		pan1.setBackground(Color.CYAN);
		pan1.add(new Label("ī��1"));
		pan2 = new Panel();
		pan2.setBackground(Color.gray);
		pan2.add(new Label("ī��2"));
		pan3 = new Panel();
		pan3.setBackground(Color.blue);
		pan3.add(new Label("ī��3"));
		pan4 = new Panel();
		pan4.setBackground(Color.red);
		pan4.add(new Label("ī��4"));
		
		//Adds the specified component to the end of this container
		//add(component,name)
		add(pan1,"1");
		add(pan2,"2");
		add(pan3,"3");
		add(pan4,"4");
	}
	
	public void next() {
		for(int i = 0; i<4; i++) {
			try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {}
			
			//next(Container parent)
			//Flips to the next card of the specified container
			//cardLayout.next(this);
			//cardLayout.first(this);
			//cardLayout.last(this);
			//cardLayout.previous(this);
			cardLayout.show(this, "3");
		}
	}

	public static void main(String[] args) {
		CardLayoutEx cardLayoutEx = new CardLayoutEx();
		cardLayoutEx.setVisible(true);
		cardLayoutEx.next();
	}
}

package awt_Ȱ��;

public class Staff extends Member{
	private String id;
	private String department;
	
	public Staff() {}
	
	public Staff(String name, String age, String sex, String addr,String id, String department) {
		super(name, age, sex, addr);
		this.id = id;
		this.department = department;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = "003_" + id;
	}

	public String getDepartment() {
		return department;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	@Override
	public String toString() {
		return "Staff [id=" + id + ", department=" + department + super.toString()+ "]";
	}	
}

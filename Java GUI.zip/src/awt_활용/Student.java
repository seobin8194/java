package awt_Ȱ��;

public class Student extends Member{
	private String id;//������ȣ
	private String classRoom;//���� Ŭ����
	
	public Student() {}

	public Student(String name, String age, String sex, String addr, String id, String classRoom) {
		super(name, age, sex, addr);
		this.id = id;
		this.classRoom = classRoom;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = "001_" + id;
	}

	public String getClassRoom() {
		return classRoom;
	}

	public void setClassRoom(String classRoom) {
		this.classRoom = classRoom;
	}

	@Override
	public String toString() {
		return "Student [id=" + id + ", classRoom=" + classRoom + super.toString() + "]";
	}	
}

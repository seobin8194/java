package awt_Ȱ��;

public class Teacher extends Member{
	private String id;
	private String subject;
	
	public Teacher() {}
	
	public Teacher(String name, String age, String sex, String addr, String id, String subject) {
		super(name, age, sex, addr);
		this.id = id;
		this.subject = subject;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = "002_" + id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	@Override
	public String toString() {
		
		return "Teacher [id=" + id + ", subject=" + subject + super.toString() + "]";
	}
}

package gui_Inner;

public class Main {
	public static void main(String args[]) {
		//new MyFrame();
		//new MyFrame2();
	}
}

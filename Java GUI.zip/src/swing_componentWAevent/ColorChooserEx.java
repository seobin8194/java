package swing_componentWAevent;

import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.MenuBar;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.SwingConstants;

public class ColorChooserEx extends JFrame{
	Container container;
	JLabel label = new JLabel("color");
	
	public ColorChooserEx() {
		setTitle("Color Chooser");
		setSize(300,300);
		
		createMenu();
		container = getContentPane();
		
		label.setFont(new Font("����",Font.BOLD,30));
		label.setHorizontalAlignment(SwingConstants.CENTER);
		label.setOpaque(true);
		
		container.add(label);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	public void createMenu() {
		JMenuBar bar = new JMenuBar();
		JMenu menu = new JMenu("�÷� ����");
		JMenuItem item = new JMenuItem("�÷�");
		
		item.addActionListener(new EventHandler());
		
		menu.add(item);
		bar.add(menu);
		
		this.setJMenuBar(bar);
	}
	
	class EventHandler implements ActionListener{
		JColorChooser color = new JColorChooser();

		@Override
		public void actionPerformed(ActionEvent e) {
			//�̺�Ʈ �ҽ��� �ؽ�Ʈ�� �����´�
			String cmd = e.getActionCommand();
			if(cmd == "�÷�") {
				//���� �ȷ�Ʈ�� �����ϴ� ��ȭ���ڸ� ����
				//showDialog(Component component,String title,Color initialColor)
				//��ȭ���ڿ��� Ȯ�ι�ư�� Ŭ���ϸ� ������ Color��ü�� ��ȯ�Ѵ�
				Color selectedColor = color.showDialog(null,"���� �ȷ�Ʈ", Color.pink);
				if(selectedColor != null) {
					//label.setForeground(selectedColor);
					label.setBackground(selectedColor);
				}
			}	
		}
	}
	
	public static void main(String[] args) {
		new ColorChooserEx();
	}
}

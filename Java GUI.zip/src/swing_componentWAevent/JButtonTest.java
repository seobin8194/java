package swing_componentWAevent;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

public class JButtonTest extends JFrame{
	Container container;
	JButton button;
	
	public JButtonTest() {
		setTitle("��ư �׽�Ʈ");
		setSize(300,300);
		
		container = getContentPane();
		//container.setLayout(new FlowLayout());
		container.setLayout(new GridLayout(1,0));
		
		ImageIcon icon1 = new ImageIcon("b1.png");
		ImageIcon icon2 = new ImageIcon("b2.png");
		ImageIcon icon3 = new ImageIcon("b3.png");
		
		//JButton(String text,Icon icon) : Creates a button with initial text and an icon.
		button = new JButton("play",icon1);
		
		//setHorizontalAlignment(int alignment)
		//Sets the horizontal alignment of the icon and text.
		button.setHorizontalAlignment(SwingConstants.LEFT);
		//setVerticalAlignment(int alignment)
		//Sets the vertical alignment of the icon and text.
		button.setVerticalAlignment(SwingConstants.BOTTOM);
		//setHorizontalTextPosition(int textPosition)
		//Sets the horizontal position of the text relative to the icon.
		button.setHorizontalTextPosition(JButton.CENTER);
		//setVerticalTextPosition(int textPosition)
		//Sets the vertical position of the text relative to the icon.
		button.setVerticalTextPosition(JButton.BOTTOM);
		
		//setToolTipText(String text)
		//���콺 �÷����� ǳ������ �����Ѵ�
		button.setToolTipText("ǳ�����Դϴ�");
		
		//setBorder(Border border) : Sets the border of this component
		//LineBorder(Color color, int thickness) : Creates a line border with the specified color and thickness
		button.setBorder(new LineBorder(Color.MAGENTA,5));
		//TitleBorder(String str) : �ؽ�Ʈ�� �� �׵θ��� ����
		button.setBorder(new TitledBorder("Ÿ��Ʋ ��ư"));
		//BevelBorder(int bevelType, Color highlight, Color shadow)
		//��ư�� ��ü���� �ش� : BeewkBorder.RAISED ���ϳ��� ��ư BevelBorder.LOWERED ��ǫ �� ��ư
		button.setBorder(new BevelBorder(BevelBorder.RAISED, Color.GRAY, Color.DARK_GRAY));
		//EtchedBorder(Color highlight, Color shadow) : ���� ��ħ
		button.setBorder(new EtchedBorder(Color.cyan, Color.red));
		
		//��ư ���� ���콺�� �÷����� �������� ����
		button.setRolloverIcon(icon2);
		//��ư�� ������ �Ջ���� �������� ����
		button.setPressedIcon(icon3);
		
		container.add(button);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new JButtonTest().setVisible(true);
	}
}

package swing_componentWAevent;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class JCheckboxTest extends JFrame{
	Container container;
	JLabel label,label2;
	JCheckBox [] lang = new JCheckBox[3];
	String [] langName = {"c���","c++","java"};
	int sum = 0;
	
	public JCheckboxTest() {
		setTitle("CHECKBOX");
		setSize(300,600);
		
		container = getContentPane();
		container.setLayout(new FlowLayout());
		
		label = new JLabel("�������� ���ϴ� �������� �����Ͻÿ�");
		
		for(int i=0; i<lang.length; i++) {
			lang[i] = new JCheckBox(langName[i],new ImageIcon("b1.png"));
			lang[i].setBorderPainted(true);
			lang[i].setSelectedIcon(new ImageIcon("b2.png"));
			
			lang[i].addItemListener(new EventHandler());	
		}
		
		label2 = new JLabel("������� 0���Դϴ�");
		
		container.add(label);
		for(int i=0;i<lang.length;i++) {container.add(lang[i]);}
		container.add(label2);
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	class EventHandler implements ItemListener{
		@Override
		public void itemStateChanged(ItemEvent e) {
			int flag = 1;
			if(e.getStateChange() == ItemEvent.SELECTED) {flag=1;}
			else {flag = -1;}
			
			if(e.getItem() == lang[0]) {
				sum += flag*10000;
			}else if(e.getItem() == lang[1]) {
				sum += flag*20000;
			}else if(e.getItem() == lang[2]) {
				sum += flag*15000;
			}
			label2.setText("������� " + sum + "�� �Դϴ�");	
		}
	}

	public static void main(String[] args) {
		new JCheckboxTest().setVisible(true);
	}
}

package swing_componentWAevent;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class JComboTest extends JFrame{
	Container container;
	String[] item = {"javascript","java","python"};
	ImageIcon[] images = {
			new ImageIcon("javascript.png"),
			new ImageIcon("java.png"),
			new ImageIcon("python.png")
	};
	JLabel label = new JLabel(images[0]);
	
	public JComboTest() {
		setTitle("ComboBox Test");
		setSize(400,400);
		
		container = getContentPane();
		container.setLayout(new FlowLayout());
		
		//JComboBox comboBox = new JComboBox(item);
		JComboBox comboBox2 = new JComboBox();
		for(int i = 0; i < item.length; i++) {
			comboBox2.addItem(item[i]);
		}
		
		comboBox2.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				JComboBox object = (JComboBox)e.getSource();
				int idx = object.getSelectedIndex();
				label.setIcon(images[idx]);
			}
		});
		
		//container.add(comboBox);
		container.add(comboBox2);
		container.add(label);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new JComboTest();
	}
}

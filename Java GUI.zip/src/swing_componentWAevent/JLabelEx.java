package swing_componentWAevent;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class JLabelEx extends JFrame{
	JLabel label1,label2,label3;
	Container container;
	
	public JLabelEx() {
		super("JLael Test");
		setSize(500,500);
		
		container = getContentPane();
		container.setLayout(new FlowLayout());
		
		//JLabel(String text)
		label1 = new JLabel("���� ����ũ");
		//�̹��� ������ ����
		//�̹����� C:\Users\������\Desktop\GUI�� �־�ߵȴ�
		ImageIcon icon = new ImageIcon("cake.png");
		//JLabel(Icon image)
		label2 = new JLabel(icon,SwingConstants.RIGHT);
		//JLabel(String text,Icon icon,int horizontalAlignment)
		label3 = new JLabel("���� Ŀ��ũ ",icon,SwingConstants.RIGHT);
		
		container.add(label1);
		container.add(label2);
		container.add(label3);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new JLabelEx();
	}
	
}

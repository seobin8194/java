package swing_componentWAevent;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JScrollPane;

public class JListTest extends JFrame{
	Container container;
	String[] item = {"����","���","�λ�","����","��õ","����","����","û��","����","�뱸","����"};
	
	public JListTest() {
		setTitle("List Test");
		setSize(400,400);
		
		container = getContentPane();
		container.setLayout(new FlowLayout());
		
		JList list = new JList(item);
		JList listScroll = new JList(item);
		JScrollPane scrollPane = new JScrollPane(listScroll);
		
		container.add(list);
		container.add(scrollPane);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new JListTest();

	}

}

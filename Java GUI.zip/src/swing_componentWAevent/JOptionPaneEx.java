package swing_componentWAevent;

import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class JOptionPaneEx extends JFrame{
	Container container;
	PanelDemo panelDemo;
	
	public JOptionPaneEx() {
		super("optionPane test");
		setSize(300,300);
		
		container = getContentPane();
		
		panelDemo = new PanelDemo();
		
		container.add(panelDemo);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	class PanelDemo extends JPanel{
		JButton inBtn = new JButton("�Է� ���̾�α�");
		JButton confirmBtn = new JButton("ȹ�� ���̾�α�");
		JButton msgBtn = new JButton("�޽��� ���̾�α�");
		JTextField textField = new JTextField(5);
		
		public PanelDemo() {
			setBackground(Color.pink);
			
			inBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					String[] msg = {"�����","��ġ","��ġ"};
					String fish = (String) JOptionPane.showInputDialog(null,"�����ϴ� ������?","����",JOptionPane.OK_OPTION,new ImageIcon("fish.png"),msg,"�����");
					if(fish != null) {
						textField.setText(fish);
					}
//					
//					String age = JOptionPane.showInputDialog("���̸� �Է��Ͻÿ�");
//					if(age != null) {
//						textField.setText(age);
//					}
				}
			});
			add(inBtn);
			
			confirmBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					
					int result = JOptionPane.showConfirmDialog(null,"��� �Ͻðڽ��ϱ�?","Ȯ��",JOptionPane.OK_CANCEL_OPTION,JOptionPane.INFORMATION_MESSAGE);
					//yes�� 0 no�� 1 ��ȯ x��ư ������ -1
//					if(result == 0) {
//						textField.setText("yes");
//					} else if(result == 1) {
//						textField.setText("no");
//					} else {
//						textField.setText("close");
//					}
					if(result == JOptionPane.YES_OPTION) {
						textField.setText("yes");
					} else if(result == JOptionPane.NO_OPTION) {
						textField.setText("no");
					} else if(result == JOptionPane.CLOSED_OPTION) {
						textField.setText("close");
					}
				}
			});
			add(confirmBtn);
			
			msgBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					JOptionPane.showMessageDialog(null, "����մϴ�","��� �޽���",JOptionPane.WARNING_MESSAGE);
				}
			});
			add(msgBtn);
			
			add(textField);
		}
	}

	public static void main(String[] args) {
		new JOptionPaneEx();
	}
}

package swing_componentWAevent;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JProgressBar;
import javax.swing.border.Border;

public class JProgressBarEx extends JFrame{
	Container container;
	JProgressBar progressBar;
	JButton button;
	
	public JProgressBarEx() {
		setTitle("progressBar");
		setSize(500,500);
		
		container = getContentPane();
		container.setLayout(new FlowLayout());
		
		Border border = BorderFactory.createTitledBorder("������ �д� ��,,,");
		
		//JProgressBar(int min, int max)
		//���� �������� ������ 0 ~ 100
		progressBar = new JProgressBar();
		//progressBar.setBorderPainted(true);
		//progressBar.setBorder(border);
		//% ǥ��
		progressBar.setStringPainted(true);
		
		button = new JButton("����");
		button.addActionListener(new EventHandler());
		
		container.add(progressBar);
		container.add(button);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);	
	}
	
	//progressbar�� �����ϴ� ������
	class MyThread extends Thread {
		public void run() {
			for(int i = progressBar.getMinimum(); i <= progressBar.getMaximum(); i++) {
				progressBar.setValue(progressBar.getMinimum() + i);
				try {sleep(100);} catch (InterruptedException e) {}
			}
		}
	}
	
	class EventHandler implements ActionListener{
		@Override
		public void actionPerformed(ActionEvent e) {
			Object object = e.getSource();
			if(object == button) {
				//��ư�� Ŭ���Ǹ� progressbar�� �����ϴ� �����带 ȣ���Ѵ�
				new MyThread().start();	
			}	
		}
	}

	public static void main(String[] args) {
		new JProgressBarEx();
	}
}

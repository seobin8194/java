package swing_componentWAevent;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.SwingConstants;

public class JRadioTest extends JFrame{
	Container container;
	JRadioButton[] lang =new JRadioButton[3];
	String[] str = {"javascript","Java","Python"};
	ButtonGroup buttonGroup;
	ImageIcon [] icons = {new ImageIcon("javascript.png"),new ImageIcon("java.png"),new ImageIcon("python.png")};
	JLabel label = new JLabel();
	
	public JRadioTest() {
		setTitle("RadioButton Test");
		setSize(900,500);
		
		container = getContentPane();
		
		JPanel panel = new JPanel();
		panel.setBackground(Color.GREEN);

		ButtonGroup buttonGroup = new ButtonGroup();
		for(int i = 0; i<lang.length; i++) {
			ImageIcon icon = new ImageIcon("b1.png");
			ImageIcon icon2 = new ImageIcon("b2.png");
			//JRadioButton(String text, Icon icon, boolean selected)
			lang[i] = new JRadioButton(str[i], icon);
			lang[i].setSelectedIcon(icon2);
			lang[i].setOpaque(false);
			//��ư���� ���� ��ȣ��Ÿ������ �۵��ϱ����� �׷����� ���� �ش�
			buttonGroup.add(lang[i]);
			lang[i].addItemListener(new EventHandler());
			
			panel.add(lang[i]);
		}
		lang[1].setSelected(true);
		
		label.setHorizontalAlignment(SwingConstants.CENTER);
		
		container.add(panel,"North");
		container.add(label,"Center");
		
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	class EventHandler implements ItemListener{
		@Override
		public void itemStateChanged(ItemEvent e) {
			for(int i = 0; i<lang.length; i++) {
				if(e.getSource() == lang[i]) {
					label.setIcon(icons[i]);
				}
			}
		}	
	}

	public static void main(String[] args) {
		new JRadioTest().setVisible(true);
	}
}

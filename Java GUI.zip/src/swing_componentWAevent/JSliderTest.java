package swing_componentWAevent;

import java.awt.Container;
import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JSlider;

public class JSliderTest extends JFrame{
	Container container;
	
	public JSliderTest() {
		setTitle("JSlider Test");
		setSize(300,300);
		
		container = getContentPane();
		container.setLayout(new FlowLayout());
		
		//JSlider(int orientation,int min,int max,int value) 
		JSlider jSlider = new JSlider(JSlider.HORIZONTAL,0,300,150);
		//bar ǥ�ÿ���
		jSlider.setPaintTicks(true);
		//bar�� ���� ���� ǥ�ÿ���
		jSlider.setMinorTickSpacing(10);
		//bar�� ū ���� ǥ�ÿ���
		//jSlider.setMajorTickSpacing(50);
		//������ ���� ǥ��
		jSlider.setPaintLabels(true);
		
		container.add(jSlider);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new JSliderTest();
	}
}

package swing_thread;

import javax.swing.JOptionPane;

public class MultiThread2 {

	public static void main(String[] args) {
		ThreadDemo1 demo1 = new ThreadDemo1();
		demo1.start();
		
		String input = JOptionPane.showInputDialog("������ �Է��ϼ���");
		System.out.println("�Է� �� : " + input + "�Դϴ�");
	}
}

class ThreadDemo1 extends Thread {
	public void run() {
		for(int i = 10; i > 0; i--) {
			System.out.println(i);
			try {Thread.sleep(1000);} catch (InterruptedException e) {}
		}
	}
}

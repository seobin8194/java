package swing_thread;

public class RunnableThreadEx implements Runnable{
	int n;
	
	public RunnableThreadEx(int n) {
		this.n = n;
	}

	@Override
	public void run() {
		int total = 0;
		for(int i = 0; i < n; i++) {
			try {Thread.sleep(500);} catch (InterruptedException e) {}
			total += i;
			System.out.println(Thread.currentThread().getName() + " : " + total);
		}	
	}
	
	public static void main(String[] args) {
		RunnableThreadEx thread = new RunnableThreadEx(3);
		Thread th = new Thread(thread);
		th.start();
		RunnableThreadEx thread2 = new RunnableThreadEx(3);
		Thread th2 = new Thread(thread2);
		th2.start();
	}
}

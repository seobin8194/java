package swing_thread;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class ThreadInSwing extends JFrame{
	Container container;
	JLabel label;
	
	public ThreadInSwing() {
		super("Swinh Thread");
		setSize(500,300);
		
		container = getContentPane();
		container.setLayout(new FlowLayout());
		
		label = new JLabel("");
		label.setFont(new Font("Dotum",Font.ITALIC,60));
		
		TimeThread thread = new TimeThread(label);
		
		add(label);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		thread.start();
	}
	
	class TimeThread extends Thread{
		JLabel label;
		
		public TimeThread(JLabel label) {
			this.label = label;	
		}
		
		public void run() {
			int n = 0;
			
			while(true) {
				label.setText(Integer.toString(n) + "  ");
				n++;
				try {sleep(1000);} catch (InterruptedException e) {}
			}	
		}
	}

	public static void main(String[] args) {
		new ThreadInSwing();
	}
}

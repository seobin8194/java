package swing_thread;

import java.awt.Color;
import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

//Ÿ�̸� 
class ThreadDemo5 implements Runnable {
	JLabel label;
	
	public ThreadDemo5(JLabel label) {
		this.label = label;
	}
	
	public void run() {
		int n = 0;
		while(true) {
			//�ʸ� ���鼭 label�� �ʸ� ǥ���Ѵ�
			label.setText(Integer.toString(n));
			n++;
			try { 
				   Thread.sleep(1000);
				} catch (InterruptedException e) {
					//Ÿ�����忡�� interrupt�Ͽ� �߻��� ���ͷ�Ʈ ���ܰ� �߻��ϸ� run() �޼ҵ� ����
					return;	
			}	
		}
	}
}

public class ThreadInterrupt extends JFrame{
	Container container;
	Thread th;
	
	public ThreadInterrupt() {
		super("������ ���� ����");
		setSize(500,500);
		
		container = getContentPane();
		container.setLayout(new FlowLayout());
		
		JLabel label = new JLabel();
		label.setFont(new Font("Dotum",Font.BOLD,60));
		
		ThreadDemo5 thr = new ThreadDemo5(label);
		th = new Thread(thr);
		th.start();
		
		JButton button = new JButton("������ ����");
		button.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				//������ ���� ����
				th.interrupt();
				JButton button = (JButton) e.getSource();
				button.setBackground(Color.green);
			}
		});
	
		container.add(label);
		container.add(button);
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);	
	}

	public static void main(String[] args) {
		new ThreadInterrupt();
	}
}

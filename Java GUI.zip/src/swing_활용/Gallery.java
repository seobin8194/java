package swing_Ȱ��;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class Gallery extends JFrame{
	Container container;
	JLabel label;
	ImageIcon[] images = new ImageIcon[4];
	int id = 0;
	
	public Gallery() {
		setTitle("Gallery");
		setSize(500,500);
		
		container = getContentPane();
		container.setLayout(new BorderLayout());
		
		for(int i = 0; i < images.length; i++) {
			images[i] = new ImageIcon("food" + (i + 1) + ".png");
		}
		
		label = new JLabel(images[id]);
		
		container.add(label,"Center");
		container.add(new ArrowBtn(),"North");
		
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	class ArrowBtn extends JPanel {
		public ArrowBtn() {
			setBackground(Color.orange);
			
			ImageIcon left = new ImageIcon("left.png");
			ImageIcon right = new ImageIcon("right.png");
			
			JButton leftBtn = new JButton(left);
			JButton rightBtn = new JButton(right);
			
			leftBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					//���� �̹���
					id--;
					id = (id + images.length) % images.length;
					
					label.setIcon(images[id]);
				}
			});
			
			rightBtn.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					//���� �̹���
					id++;
					id = (id + images.length) % images.length;
					
					label.setIcon(images[id]);
				}
			});
			
			add(leftBtn);
			add(rightBtn);		
		}	
	}

	public static void main(String[] args) {
		new Gallery();
		

	}

}

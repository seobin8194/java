package Stream;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedInOutStream1 {

	public static void main(String[] args) throws IOException{
		String filename = args[0];
		BufferedInputStream bin = null;
		BufferedOutputStream bo = null, bo1 = null;
		FileInputStream fin = new FileInputStream(filename);
		FileOutputStream fo = new FileOutputStream("TEST2.txt", true);
		
		//nodeStream ����
		bin = new BufferedInputStream(fin);
		bo = new BufferedOutputStream(System.out);
		bo1 = new BufferedOutputStream(fo);
		
		int n = 0;
		byte buf[] = new byte[512];
		
		while((n=bin.read(buf)) != -1) {
			bo.write(buf,0,n);
			bo.flush();
			
			bo1.write(buf,0,n);
			bo1.flush();
		}
		
		bin.close();
		bo.close();
		bo1.close();
		fin.close();
		fo.close();
		System.out.close();
	}

}

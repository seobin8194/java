package Stream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.Arrays;

public class ByteArrayTest1 {

	public static void main(String[] args) {
		byte[] input = {0,1,2,3,4,5,6,7,8,9};
		byte[] output = null;
		
		byte[] buff = new byte[10];
		
		ByteArrayInputStream ins = null;
		ByteArrayOutputStream outs = null;
		
		ins = new ByteArrayInputStream(input);
		outs = new ByteArrayOutputStream();
		
		int n = 0;//�о� �� ������
		
		ins.read(buff, 0, input.length);
		outs.write(buff, 4, 5);
		
		/*while((n = ins.read()) != -1) {
			//System.out.println(n);
			outs.write(n);
		}*/
		
		//toByteArray() : 
		output = outs.toByteArray();
		
		//for���� �̿����� �ʰ� �迭 ���� ����ϱ�
		//Arrays.toString() : 
		System.out.println(Arrays.toString(output));
	}
}

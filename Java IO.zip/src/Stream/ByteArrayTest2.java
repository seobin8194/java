package Stream;

import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.util.Arrays;

public class ByteArrayTest2 {

	public static void main(String[] args) {
		try {
			FileInputStream fn = new FileInputStream(args[0]);
			ByteArrayOutputStream byteOut = new ByteArrayOutputStream();
			
			byte[] output = null;
			byte[] buff = new byte[512];
			int n;
			
			while((n = fn.read(buff)) != -1) {
				byteOut.write(buff, 0, n);
			}
			output = byteOut.toByteArray();
			
			System.out.write(output, 0, output.length);
	
		} catch (Exception e) {e.printStackTrace();}
	}
}

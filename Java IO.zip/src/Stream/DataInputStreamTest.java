package Stream;

import java.io.DataInputStream;
import java.io.FileInputStream;

public class DataInputStreamTest {

	public static void main(String[] args) throws Exception {
		FileInputStream fin = new FileInputStream("TEST.txt");
		DataInputStream din = new DataInputStream(fin);
		
		System.out.println(din.readInt());
		System.out.println(din.readFloat());
		System.out.println(din.readBoolean());
		
		din.close();
	
	}
}

package Stream;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class DataOutputStreamTest {

	public static void main(String[] args) {
		FileOutputStream fo = null;//nodeStream
		DataOutputStream dout = null;
		
		try {
			fo = new FileOutputStream("TEST.txt");
			dout = new DataOutputStream(fo);
			
			//�����͸� 16���� ���·� ����
			dout.writeInt(100);
			dout.writeFloat(10.0f);
			dout.writeBoolean(true);
			
			dout.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}

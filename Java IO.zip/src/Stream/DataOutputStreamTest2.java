package Stream;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;

public class DataOutputStreamTest2 {

	public static void main(String[] args) {
		int jumsu [] = {90, 80, 100, 80, 75};
		
		try {
			FileOutputStream fo = new FileOutputStream("TEST.txt");
			DataOutputStream dout = new DataOutputStream(fo);
			
			for(int i = 0; i<jumsu.length;i++) {
				dout.writeInt(jumsu[i]);
			}
			
			dout.close();
		} catch (Exception e) {e.printStackTrace();}
	}
}

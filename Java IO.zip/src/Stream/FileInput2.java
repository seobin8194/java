package Stream;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class FileInput2 {

	public static void main(String[] args) {
		String fname = args[0];
		
		try {
			FileInputStream fn =new FileInputStream(fname);
			int n = 0;//���� ����Ʈ
			int cnt = 0;//�ݺ� Ƚ��
			byte bb[] = new byte[1024];
			
			while((n = fn.read(bb)) != -1) {
				System.out.println("n : " + n);
				System.out.write(bb, 0, n);
				System.out.println(new String(bb));
				
				cnt++;
			}
			
			System.out.println("cnt : " + cnt);
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

}

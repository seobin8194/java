package Stream;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class FileReaderAndFileWriterTest {

	public static void main(String[] args) throws IOException {
		File fsrc = new File("TEST.txt");//�ҽ�����
		File ftarget = new File("TEST2.txt");//Ÿ������
		
		FileReader fr = null;
		FileWriter fw = null;
		BufferedReader buffin = null;
		BufferedWriter buffout = null;
		
		int n;
		
		fr = new FileReader(fsrc);
		fw = new FileWriter(ftarget);
		buffin = new BufferedReader(fr);
		buffout = new BufferedWriter(fw);
		
		while((n = buffin.read()) != -1) {
			buffout.write((char)n);
		}
		
		buffin.close();
		buffout.close();
		fr.close();
		fw.close();
	}
}

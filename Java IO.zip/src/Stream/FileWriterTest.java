package Stream;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class FileWriterTest {

	public static void main(String[] args) throws IOException {
		String res = "TEST.txt";
		File file = new File(res);
		FileWriter fw = new FileWriter(file);
		
		for(int i=0; i<10; i++) {
			fw.write("line : " + i + "\n");
		}
		fw.close();
	}
}

package Stream;

import java.io.RandomAccessFile;

public class RandomAccessFileTest2 {

	public static void main(String[] args) throws Exception {
		int [] jumsu = { 100, 80, 90,
				         88, 90, 100,
				         60, 70, 90,
				         50, 40, 66 };
		RandomAccessFile ra = new RandomAccessFile("jumsu.txt", "rw");
		
		for(int i = 0; i<jumsu.length; i++) {
			ra.writeInt(jumsu[i]);
		}
		
/*		ra.seek(0);
		
		for(int i = 0; i<jumsu.length; i++) {
			System.out.println(ra.readInt());
		}*/
		
		int pnt = (int) ra.getFilePointer();
		for(int i = pnt; i>0; i-=4) {
			ra.seek(i-4);
			System.out.println(ra.readInt());
		}
	}
}

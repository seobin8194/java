package Stream;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Date;

public class ReadPersonInfo {

	public static void main(String[] args) throws Exception {
		String fname= "obj.ser";
		FileInputStream fi = new FileInputStream(fname);
		BufferedInputStream bi = new BufferedInputStream(fi);
		ObjectInputStream oi = new ObjectInputStream(bi);
		
		//������ȭ
     	//��ü�� ������ ������ ���� �;� �Ѵ�
		PersonInfo p1 = (PersonInfo) oi.readObject();
		PersonInfo p2 = (PersonInfo) oi.readObject();
		ArrayList<PersonInfo> list = (ArrayList<PersonInfo>) oi.readObject();
		Date date = (Date) oi.readObject();
		
		System.out.println(p1);
		System.out.println(p2);
		System.out.println(list);
		System.out.println("��ü�� ����� �ð�" + date.toString());
		System.out.println("���� �ð�" + new Date().toString());
		
		oi.close();
	}
}

package Stream;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Date;

public class SavePersonInfo {

	public static void main(String[] args) throws Exception {
		String fname = "obj.ser";
		FileOutputStream fo = new FileOutputStream(fname);
		BufferedOutputStream bo = new BufferedOutputStream(fo);
		ObjectOutputStream out = new ObjectOutputStream(bo);
		
		PersonInfo p1 = new PersonInfo("edc1107", "wtq8194", "seobin");
		PersonInfo p2 = new PersonInfo("id1234", "pw5678", "seoho");
		
		ArrayList<PersonInfo> a1 = new ArrayList<>();
		a1.add(p1);
		a1.add(p2);
		
		//����ȭ
		out.writeObject(p1);
		out.writeObject(p2);
		out.writeObject(a1);
		out.writeObject(new Date());//��ü�� ������ �ð��� ���� �����Ѵ�
		
		out.close();
		fo.close();
		bo.close();
		System.out.println("����ȭ�Ǿ����ϴ�");
	}

}

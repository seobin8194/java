package Stream;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintStream;

public class SystemInOutTest {

	public static void main(String[] args) throws IOException {
		//��� ��Ʈ�� :System.in System.out System.err -> ǥ�� �����
		//�긮�� ��Ʈ�� : InputStreamReader outputStreamWriter
		InputStream is = System.in;
		PrintStream po = System.out;
		PrintStream pe = System.err;
		
		InputStreamReader ir = new InputStreamReader(is);
		OutputStreamWriter ow = new OutputStreamWriter(po);
		OutputStreamWriter ow2 = new OutputStreamWriter(pe);
		
		int data = 0;
		while((data = ir.read()) != -1) {
			ow2.write(data);
			ow2.flush();
		}
		
		ir.close();
		ow.close();
		ow2.close();
		is.close();
		po.close();
		pe.close();
	}
}

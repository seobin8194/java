package Stream;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class SystemInOutTest2 {

	public static void main(String[] args) throws IOException {
		InputStreamReader ir = null;
		OutputStreamWriter ow = null;
		
		ir = new InputStreamReader(System.in);
		ow = new OutputStreamWriter(System.out);
		
		BufferedReader br = null;
		BufferedWriter bw = null;
		
		br = new BufferedReader(ir);
		bw = new BufferedWriter(ow);
		
		int data = 0;
		while((data = br.read()) != -1) {
			bw.write(data);
			bw.flush();
		}
		
		ir.close();
		ow.close();
		br.close();
		bw.close();
	}
}

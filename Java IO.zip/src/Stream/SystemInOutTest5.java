package Stream;

import java.io.FileInputStream;
import java.io.IOException;

public class SystemInOutTest5 {

	public static void main(String[] args) throws IOException {
		FileInputStream fi = new FileInputStream("TEST.txt");
		
		System.setIn(fi);
		
		int data;
		while((data = System.in.read()) != -1) {
			System.out.println((char)data);
		}
	}
}

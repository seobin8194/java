import java.net.URL;
import java.net.URLConnection;

public class URLConnectionTest {

	public static void main(String[] args) throws Exception {
		String str = "https://imgnews.pstatic.net/image/009/2010/07/11/health_20100711_2010071100041.jpg?type=w647";
		URL url = new URL(str);
		
		//openConnection() : URLConnection ��ü ��ȯ
		URLConnection conn = url.openConnection();
		
		System.out.println("toString() " + conn.toString());
		System.out.println("���� ������ " + conn.getContentLength());//-1
		System.out.println("���� Ÿ�� " + conn.getContentType());
		System.out.println("���� ��¥ " + conn.getDate());
	}
}

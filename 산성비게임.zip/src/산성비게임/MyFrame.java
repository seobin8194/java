package �꼺�����;

import java.awt.Component;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.security.Key;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;


public class MyFrame extends JFrame{
	JLabel ans=new JLabel("����");
	JTextField text=new JTextField(10);
	JButton start=new JButton("����");
	JPanel panel=new JPanel();
	
	MyCanvas can=new MyCanvas();
	MyThread th=new MyThread(can);
	AddString st=new AddString(can);
	
	public MyFrame() {
		setBounds(400,300,500,500);
		setVisible(true);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
		panel.setLayout(new GridLayout(1,3));
		ans.setFont(new Font("����",Font.BOLD,30));
		panel.add(ans);
		panel.add(text);
		panel.add(start);

		add("South",panel);
		add(can);
		
		st.start();
		th.start();
		
		text.addKeyListener(new KeyAdapter() {
			@Override
			public void keyPressed(KeyEvent e) {
				if(e.getKeyCode()==10) {
					for(int i=0;i<can.list.size();i++) {
						if(can.list.get(i).str==text.getText()) {
							can.list.remove(i);
							
						}
						
					}
					text.setText("");
				}
				
			}
		});
	}

}
